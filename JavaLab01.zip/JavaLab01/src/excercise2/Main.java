/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excercise2;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author ICQ
 */
public class Main {

    public static void main(String[] args) {
        int counter = 0;
        char[] name = {'p', 'l', 'a', 'y'};
        char[] pname = {'*', '*', '*', '*'};
        System.out.println("Guess the word and it contains 4 letters :)");
        Scanner input = new Scanner(System.in);
        char c;
        boolean test = false;
        while (counter <= 5 && !Arrays.equals(name, pname)) {
            c = input.next().charAt(0);
            for (int i = 0; i < name.length; i++) {
                if (c == name[i]) {
                    pname[i] = c;
                    test = true;
                    for (char j : pname) {
                        System.out.print(j);
                    }
                    System.out.println();
                }

            }
            if (test == false) {
                counter++;
            }
            test = false;

        }
        System.out.println("you have made " + counter + " mistakes");

    }
}
