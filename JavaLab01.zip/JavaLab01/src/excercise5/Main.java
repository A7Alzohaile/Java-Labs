/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excercise5;

/**
 *
 * @author ICQ
 */
public class Main {

    static boolean check(int n) {
        int m, test = 0;

        m = n / 2;
        for (int i = 2; i <= m; i++) {
            if (n % i == 0) {
                test = 1;
                break;
            }
        }
        if (test == 0) {
            return true;
        }
        return false;
    }

    static boolean isdigitpresent(int n) {
        while (n > 0) {
            if (n % 10 == 9) {
                break;
            }
            n = n / 10;
        }
        return (n > 0);

    }

    public static void main(String[] args) {
        int n = 3, sum = 0, counter = 0;
        while (n < 1000) {
            if (check(n) && isdigitpresent(n)) {
                counter++;
                sum += n;
            }
            n++;
        }
        System.out.println(sum / counter);

    }

}
