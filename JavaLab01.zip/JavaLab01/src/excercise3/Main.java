/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excercise3;

/**
 *
 * @author ICQ
 */
public class Main {

    public static void main(String[] args) {
        int a, b, c, sum = 0;
        a = 0;
        b = 1;
        c = a + b;
        //System.out.println(a);
        while (c < 4000) {
            a = b;
            b = c;
            c = a + b;
            if (c % 2 == 0) {
                sum += c;
            }
        }
        System.out.println(sum);
    }

}
