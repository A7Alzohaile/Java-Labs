/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Excercise1;

import java.util.Scanner;

/**
 *
 * @author ICQ
 */
public class Main {

    public static void main(String[] args) {
        int score = 0;
        System.out.println("Hi Welcome to quiz :) \n Q1 - Which of the below is valid way to instantiate an array in java? \n"
                + "  1- int myArray [] = {1, 3, 5}; \n"
                + "  2- int [] myArray = (5, 4, 3); \n "
                + "Q2 - Which of the following statements are true for inheritance in java? \n "
                + " 1- You can extend multiple classes in java. \n "
                + " 2- We can’t extend Final classes in java.\n"
                + " Q3 - Can we have two main methods in a java class?\n"
                + "  1 -Yes \n"
                + "  2 -No \n "
                + "Please type your answers :) "
                + "answer for Q1 = ");
        Scanner input = new Scanner(System.in);
        int answer1 = input.nextInt();
        if (answer1 == 1) {
            score++;
        }
        System.out.println("answer for Q2 = ");
        int answer2 = input.nextInt();
        if (answer2 == 1) {
            score++;
        }
        System.out.println(" answer for Q3 = ");
        int answer3 = input.nextInt();
        if (answer3 == 2) {
            score++;
        }
        System.out.println("Your score is " + score);

    }

}
