
package fibonaccifinalabstraction;


public class Count3Filter extends Filter {
    @Override
    public boolean IsAccepted(Object obj){
        return String.valueOf(obj).contains("3"); 
    }
}
