
package fibonaccifinalabstraction;

interface Iiterable {
   Iiterator GetIterator();   
}
