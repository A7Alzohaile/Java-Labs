
package fibonaccifinalabstraction;

public class FibonacciFinalAbstraction {

    public static void main(String[] args) {
       int sum=0;
       try{
           /*       sum = (int)((Sequence)(new FibonacciSequence(1000).GenerateList())
           .AcceptFilter(new Count3Filter()))
           .AcceptAggregator(new SumAggregator());*/
           
    Sequence seq = new FibonacciSequence(4000);
    seq.GenerateList();
    Iiterator fiboIterator = seq.GetIterator();
 
    
    while(fiboIterator.HasNext()){
        System.out.println(fiboIterator.GetNext());
    }
    fiboIterator.GetNext();
    System.out.println(fiboIterator.GetNext());
    }catch(ClassCastException e){
           System.err.println("cast exception");
           System.exit(1);
    }finally{
           System.out.println(sum);   
     }
    
}
    }
