
package fibonaccifinalabstraction;


 interface IAggregatabale {
   public  Object AcceptAggregator(Aggregator aggregatorObject); 
}
