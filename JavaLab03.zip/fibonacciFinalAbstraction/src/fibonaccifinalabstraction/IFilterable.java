
package fibonaccifinalabstraction;


interface IFilterable {
   public  IFilterable AcceptFilter(Filter filterObject); 
}
