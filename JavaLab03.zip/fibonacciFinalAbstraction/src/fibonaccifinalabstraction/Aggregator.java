
package fibonaccifinalabstraction;
import java.util.ArrayList;
public abstract class Aggregator {
    public abstract Object DoAggregate(ArrayList<Object> list);
    
}
