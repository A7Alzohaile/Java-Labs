
package fibonaccifinalabstraction;

public abstract class NumericalSequence extends Sequence{
    
}
