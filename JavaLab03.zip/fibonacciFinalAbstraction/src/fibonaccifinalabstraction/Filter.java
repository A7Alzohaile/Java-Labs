
package fibonaccifinalabstraction;

public abstract class Filter {
  public abstract boolean IsAccepted(Object obj);
}
