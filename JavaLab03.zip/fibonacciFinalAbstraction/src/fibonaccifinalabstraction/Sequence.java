
package fibonaccifinalabstraction;

import java.util.ArrayList;

public abstract class Sequence implements IFilterable , IAggregatabale,Iiterable{    
    ArrayList<Object> Elements = new ArrayList<Object>();
    ArrayList<Object> Temp = new ArrayList<Object>();
    protected Object StartElement;
    protected Object EndElement;
    public abstract Sequence GenerateList();
    public abstract Sequence AcceptFilter(Filter filterObject);
    public abstract Object AcceptAggregator(Aggregator aggregatorObject);
    public class SequenceIterator{
    private int index=0;
    public boolean HasNext(){
    return this.index<Elements.size();
    }
    public Object GetNext(){
    return Elements.get(this.index++);
    }
    }
    public abstract Iiterator GetIterator();
}
