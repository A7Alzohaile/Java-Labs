
package fibonaccifinalabstraction;

import java.util.ArrayList;

public class FibonacciSequence extends Sequence{
    public FibonacciSequence(int endElement){
        this.StartElement = 1;
        this.EndElement = endElement;
}
        
 public Sequence GenerateList(){
        int f1 = 1, f2 = 1;
        Elements.add(f1);
        while (f2<(int)this.EndElement)
        {
            Elements.add(f2);
            f2 = f1+f2; f1 = f2-f1; 
        }
        return this;
}
public Sequence AcceptFilter(Filter filterObject){
    for (int i= 0;i<Elements.size();i++)
        {
            if(filterObject.IsAccepted(Elements.get(i)))
                {
                    Temp.add(Elements.get(i));
		}
	
        }
    return this;
} 
public Object AcceptAggregator(Aggregator aggregatorObj){
      return aggregatorObj.DoAggregate(Temp);	    
}
public class FibonacciSequenceIterator extends SequenceIterator implements Iiterator{
private int ind = 0;
public boolean HasNext(){
    if (ind<Elements.size())
        return (int)Elements.get(this.ind)<(int)EndElement;
    else
        return ((int)Elements.get(this.ind-1)
                +(int)Elements.get(this.ind-2))
               < (int)EndElement;
}
public Object GetNext(){
    if (Elements.size()<=ind)
        Elements.add((int)Elements.get(this.ind-1)
                    +(int)Elements.get(this.ind-2));

        return (int)Elements.get(this.ind++);
}

}
@Override
public Iiterator GetIterator(){
    return new FibonacciSequenceIterator();
}
}
