
package fibonaccifinalabstraction;

public class EvenNumberFilter extends Filter{
    @Override
    public boolean IsAccepted(Object obj){
        return ((int)obj)%2 == 0; 
    }
            
}
