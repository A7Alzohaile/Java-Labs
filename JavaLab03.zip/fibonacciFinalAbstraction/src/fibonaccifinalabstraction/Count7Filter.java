
package fibonaccifinalabstraction;

public class Count7Filter extends Filter {
    @Override
    public boolean IsAccepted(Object obj){
        return String.valueOf(obj).contains("7"); 
    }
}
