
package fibonaccifinalabstraction;

interface Iiterator {
    boolean HasNext();
    Object GetNext();
}
