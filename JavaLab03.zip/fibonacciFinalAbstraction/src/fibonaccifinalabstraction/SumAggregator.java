
package fibonaccifinalabstraction;
import java.util.ArrayList;

public class SumAggregator extends Aggregator{
    int sum = 0;
    public Object DoAggregate(ArrayList<Object> list){
    for (int i = 0; i < list.size(); i++) {
      sum+=(int)list.get(i);
    }
       return sum;
   }
    
}
