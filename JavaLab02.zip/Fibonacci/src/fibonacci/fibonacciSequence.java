
package fibonacci;
import java.util.ArrayList;

public class fibonacciSequence {
    int f1 = 1, f2 = 1;
    ArrayList<Integer> arr = new ArrayList<Integer>();  
    ArrayList<Integer> temp = new ArrayList<Integer>();
    public void generateList(int limit)
    {
        arr.add(f1);
        while (f2<limit)
        {
            arr.add(f2);
            f2 = f1+f2; f1 = f2-f1; 
        }  
            System.out.println(arr);
    }
    public void AcceptFilter(Filter filterObject)
    {
        for (int i= 0;i<arr.size();i++)
        {
            if(filterObject.IsAcceptable(arr.get(i)))
          {
            temp.add(arr.get(i));
          }
        } 
    }
    public int AcceptAggregator(Aggregator aggregatorObj)
    {
      return aggregatorObj.AcceptAggregator(temp);
       
    }
    public void printSequence()
    {
            System.out.print(temp);
            System.out.println("");
    }
}  