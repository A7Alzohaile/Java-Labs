
package fibonacci;
 
public class CountFilter extends Filter {
    public boolean IsAcceptable(Object obj)
    {
        return (String.valueOf(obj).contains("7") ? true : false); //count true if it contains 7
    }
}
