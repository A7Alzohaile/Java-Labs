
package fibonacci;
import java.util.ArrayList;
public abstract class Aggregator {
    public abstract int AcceptAggregator(ArrayList<Integer> list);
}
