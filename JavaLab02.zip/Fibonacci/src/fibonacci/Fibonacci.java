
package fibonacci;

public class Fibonacci {

    public static void main(String[] args) {
        fibonacciSequence f = new fibonacciSequence();
        f.generateList(400);
        f.AcceptFilter(new EvenFilter());
        f.printSequence();
        System.out.println(f.AcceptAggregator(new SumAggregator()));
    }
    
}
