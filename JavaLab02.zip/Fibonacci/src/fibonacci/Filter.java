
package fibonacci;

public abstract class Filter {
  public abstract boolean IsAcceptable(Object obj);
          
}
