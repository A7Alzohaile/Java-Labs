
package fibonacci;

public class EvenFilter extends Filter{
    public boolean IsAcceptable(Object obj)
    {
        return ((int)obj)%2 == 0; 
    }
}
