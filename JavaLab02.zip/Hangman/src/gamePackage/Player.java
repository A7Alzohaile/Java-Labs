
package gamePackage;


abstract public class Player {
    private SingleGame currentGame;
    public abstract void Win();
    public abstract void Lose();
    public abstract void GetNextLetter();
    public abstract void OutputResult(String result);
    public SingleGame StartANewGame()
    {
        return currentGame;
    }
    public SingleGame StartANewGame(WordGenerator generator)
    {
        this.currentGame = new SingleGame(generator);
        this.GetNextLetter();
        return currentGame;
    }
    public void MakeGuess(char letter)
    {
     GameState state = this.currentGame.AcceptGuess(letter);
     if (state == GameState.PlayerWin) 
     {
         this.Win();
     }
     if (state == GameState.PlayerLose) this.Lose();
     if (state == GameState.RunningGame)
     {
         String word = this.currentGame.getGuessedWord();
         this.OutputResult(word);
         this.GetNextLetter();
     }
    }
    
}
