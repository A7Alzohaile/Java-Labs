
package gamePackage;

import java.util.Scanner;

public class ConsolePlayer extends Player{
  @Override 
  public void Win()
  {
      System.out.println("congrats..You win ^-^");
  }
  @Override
  public void Lose()
  {
      System.out.println("You lost :( ...");
  }
  @Override
  public void GetNextLetter()
  {
     Scanner sc = new Scanner(System.in);
     char c = sc.next().charAt(0);
     MakeGuess(c);
  }
  @Override
  public void OutputResult (String result)
  {
      System.out.println(result);
  }
  
    
}
