
package gamePackage;

 abstract public class WordGenerator {
     public abstract String GenerateWord();
}
