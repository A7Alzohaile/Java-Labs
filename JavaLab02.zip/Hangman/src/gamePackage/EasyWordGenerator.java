
package gamePackage;
import java.util.Random;
public class EasyWordGenerator extends WordGenerator{
    private String [] arr = {"amen","moy","loading","bored"};
    @Override
    public String GenerateWord ()
    {
        Random rand = new Random();
        int res =   rand.nextInt(arr.length);
        return arr[res];
    }
    
}
