
package gamePackage;
import java.util.Arrays;
public class SingleGame {
    private String hiddenWord;
    private String guessedWord;
    private GameState state;
    private int score;
    private WordGenerator generator;
    private GameRules g;
    
    public SingleGame() {}
    public SingleGame(WordGenerator generator) 
    {
        g = new GameRules();
        hiddenWord = generator.GenerateWord();
        guessedWord = generateGuessedWord(hiddenWord.length());
        score = hiddenWord.length();
        System.out.println("Guess the word");
        System.out.println(guessedWord);
        
    }
    public String generateGuessedWord (int size)
    {
        char[] temp = new char[size];
        Arrays.fill(temp,'*');
        return new String(temp); //conver char to string    
    }
    public boolean ifCharExist(char letter)
    {
        return hiddenWord.indexOf(letter) !=-1;
    }
    public GameState AcceptGuess(char letter) 
    {
        if (ifCharExist(letter))
        {
            g.repeatCheck(letter);
            if(guessedWord.contains("*"))
            {      
            int index = hiddenWord.indexOf(letter);
            guessedWord = guessedWord.substring(0, index) //replaca char at specified index;
              + letter
              + guessedWord.substring(index + 1);
            if(guessedWord.contains("*"))state = GameState.RunningGame; //we check again here because if the word completed then we don't need to continue the game 
            else state = GameState.PlayerWin;
            }
            else state = GameState.PlayerWin;
            return state;
        }
        if (score==1)
        {
            state = GameState.PlayerLose;
        }
        else
        {
            score--;
            state = GameState.RunningGame;
        }
        return state;
    }
    public String GetHiddenWord () 
    {
        return hiddenWord;
    }   
    public String getGuessedWord() {
        return guessedWord;
    }
    public GameState GetGameState ()
    {
        return state;
    }
    public int getScore() {
        return score;
    }
  class GameRules{
      private void repeatCheck (char letter)
      {
          if (guessedWord.indexOf(letter) !=-1)
              System.out.println("plz don't repeate this");
      }
  }  
    
}