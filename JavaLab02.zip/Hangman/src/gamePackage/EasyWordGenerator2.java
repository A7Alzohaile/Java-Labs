
package gamePackage;
import java.util.Random;
public class EasyWordGenerator2 extends WordGenerator{
    private String [] arr = {"Lion","lise","munchen"};
    @Override
    public String GenerateWord(){
    Random r = new Random();
    int res = r.nextInt(arr.length);
    return arr[res];
     }
}
