
package gamePackage;

enum GameState
{
    NewGame,RunningGame,PlayerWin,PlayerLose
}
