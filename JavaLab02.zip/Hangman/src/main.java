import gamePackage.* ;

public class main {

    public static void main(String[] args) {
      ConsolePlayer currentPlayer = new ConsolePlayer();
      WordGenerator generator  = new EasyWordGenerator();
      currentPlayer.StartANewGame(generator);
      
    }
    
}
