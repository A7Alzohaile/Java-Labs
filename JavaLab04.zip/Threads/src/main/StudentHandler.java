
package main;

 class StudentHandler extends Thread{
     private Stats stats;
     private String line;
     public StudentHandler(String line){
         this.line = line;
         this.stats = Stats.getObj();
     }
    public void run(){
        Student tmp = new Student(this.line);
        this.stats.update(tmp.getGrade());
    }
}
