
package main;

import  java.util.Scanner;
import  java.io.File;
import  java.io.FileNotFoundException;
import  java.util.ArrayList;
public class Student {
    public static  int PassingDegree = 60;
    public static int SubjectsCount = 4;
    private String name;
    private ArrayList<Integer> marks = new ArrayList<Integer>();
    public Student (){}
    public Student (String line){
          this.readStudent(line);
    }
    public void readStudent(String line){
       String[] array = line.split(" ",-1);
       for (int i = 1;i<array.length;i++)
       {
             this.marks.add(Integer.valueOf(array[i]));
          
       }
           
    }
    public double getAverage(){
        double sum = 0;
        for (int i:marks){
            sum+=i;
        }
        return (sum/marks.size());
    }
        public static Grade getGrade(double avg){
            if (avg>=95) return Grade.Honours;
            if (avg>=85) return Grade.Excellent;
            if (avg>=75) return Grade.VeryGood;
            if (avg>=65) return Grade.Good;
            if (avg>=60) return Grade.Acceptable;
            return Grade.Fail;
            
        }
    public Grade getGrade(){
        return Student.getGrade(this.getAverage());
    }
    @Override
    public  String toString(){
        return String.format("%s \t %d \t %d \t %d \t %d %n", this.name,this.marks.get(0),this.marks.get(1),this.marks.get(2),this.marks.get(3));
    }
}
