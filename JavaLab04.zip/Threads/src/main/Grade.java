
package main;

enum Grade {
    Honours,
    Excellent,
    VeryGood,
    Good,
    Acceptable,
    Fail
}
