
package main;

import  java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Main {

    public static void main(String[] args) {
        int stdcount =0;
        String st;
        try {
            BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Tech_Bo$$\\Documents\\NetBeansProjects\\Lab5_threads\\Student.txt"));
            while((st=br.readLine())!=null)
                stdcount++;
            BufferedReader b1 = new BufferedReader(new FileReader("C:\\Users\\Tech_Bo$$\\Documents\\NetBeansProjects\\Lab5_threads\\Student.txt"));
            StudentHandler[] sh = new StudentHandler[stdcount];
            st = b1.readLine();
                for (int i= 0;i<stdcount;i++)
            {
                sh[i] = new StudentHandler(st);
                sh[i].start();
                 st = b1.readLine();
            }
            for (int i= 0;i<stdcount;i++)
            {
                try {
                    sh[i].join();
                } catch (InterruptedException ex) {
                    Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            System.out.println(Stats.getObj());
        } catch (FileNotFoundException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
}
