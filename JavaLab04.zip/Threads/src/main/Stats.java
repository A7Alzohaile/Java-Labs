
package main;

public class Stats {
    private static Stats x = null;
    private int[] StatsInGrade = new int [Grade.values().length];
    private Stats(){
    }
    public static Stats getObj(){
        if (Stats.x==null)
            Stats.x=new Stats();
        return Stats.x;
    }
    public synchronized void update(Grade x){
        try {
            int a = this.StatsInGrade[x.ordinal()];
            Thread.sleep(1000);
            this.StatsInGrade[x.ordinal()] = a+1;
        } catch (InterruptedException e) {}
    }
    @Override
    public String toString(){
        String retObj = "";
        int acc = 0;
        for (Grade g: Grade.values()){
            retObj+= String.format("%s: \t %d %n",
                   this.GradesNames[g.ordinal()],
                    this.StatsInGrade[g.ordinal()]);
            acc+=this.StatsInGrade[g.ordinal()];
        }
        retObj+= String.format("%s: \t %d %n","All",acc);
        return retObj;
    }
    private static String[] GradesNames = 
            {"Honours","Excellent","VeryGood","Good", "Acceptable","Fail"};
}
